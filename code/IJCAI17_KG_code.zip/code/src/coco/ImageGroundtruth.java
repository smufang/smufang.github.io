package coco;
import java.util.ArrayList;

public class ImageGroundtruth {
	public int imageId;
	public int width;
	public int height;
    public ArrayList<CocoAnnotation> annotations;  //annotations for this image
	
	public ImageGroundtruth(int imageId, int width, int height) {
        this.imageId = imageId;
		this.width = width;
		this.height = height;
        annotations = new ArrayList<CocoAnnotation>();
    }
}
