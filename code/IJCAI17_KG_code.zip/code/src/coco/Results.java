package coco;


import java.util.Map;

public abstract class Results {

	public Map<Integer, ImageResult> imageMap;
	
	public abstract boolean read(String fin);
	
	public abstract boolean write(String fout);
	
}
