package coco;



//class representing a single image detection
public class CocoDetection {
    public int imageId;
    public int categoryId;
    public double[] bbox;
    public double score;
    
    public CocoDetection(int imageId, int categoryId, double[] bbox, double score) {
        this.imageId = imageId;
        this.categoryId = categoryId;
        this.bbox = bbox;
        this.score = score;
    }
    
    
    public double computeArea() {
    	return bbox[2] * bbox[3];
    }
    
    private double sqr(double x) {
    	return x * x;
    }
    
    public double computeDistance(CocoDetection d) {
    	double x1 = bbox[0] + bbox[2] / 2;
    	double y1 = bbox[1] + bbox[3] / 2;
    	double x2 = d.bbox[0] + d.bbox[2] / 2;
    	double y2 = d.bbox[1] + d.bbox[3] / 2;
    	return Math.sqrt(sqr(x1-x2) + sqr(y1-y2));
    }
    
    private double getIntvl(double a1, double b1, double a2, double b2) {
    	if (b1 <= a2 || b2 <= a1)
    		return 0;
    	else 
    		return Math.min(b1, b2) - Math.max(a1, a2);
    }
    
    public double computeOverlap(CocoDetection d) {
    	double width = getIntvl(bbox[0], bbox[0] + bbox[2], d.bbox[0], d.bbox[0] + d.bbox[2]);
    	double height = getIntvl(bbox[1], bbox[1] + bbox[3], d.bbox[1], d.bbox[1] + d.bbox[3]);
    	return width * height;
    }
    
    public double computeOverlapNorm(CocoDetection d) {
    	double intersection = computeOverlap(d);
    	double union = this.computeArea() + d.computeArea() - intersection;
    	return  intersection / union;
    }
    
    public CocoDetection(CocoDetection cocoDetection) {
    	this(cocoDetection.imageId, cocoDetection.categoryId, cocoDetection.bbox, cocoDetection.score);
    }
}
