package coco;

import java.util.ArrayList;
import java.util.List;


//hold the detections for one image
public class ImageResult {
    public int imageId;
    public List<CocoDetection> detections;  //detections for this image
    
    public ImageResult(int imageId) {
        this.imageId = imageId;
        detections = new ArrayList<CocoDetection>();
    }
    
    public void print() {
    	System.out.println("ImageID: " + imageId);
    	for (int i = 0; i < detections.size(); i++) {
    		System.out.println("Detection " + i + ": " + detections.get(i).categoryId + " " + detections.get(i).score);
    	}
    }
    
        
}
