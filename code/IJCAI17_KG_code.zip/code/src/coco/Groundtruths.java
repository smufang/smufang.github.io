package coco;

import java.util.Map;

public abstract class Groundtruths {
	
	public Map<Integer, ImageGroundtruth> imageMap;
	
	public abstract boolean read(String fin);
}
