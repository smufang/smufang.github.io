package main;

import graph.Edge;
import graph.Graph;
import graph.Node;


import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import coco.CocoDetection;

public class ResultProcessor {

	private SimMatrix simMatrix;
	private int knn;
	private double alpha;
	private int nIter;
	
	public ResultProcessor(SimMatrix simMatrix, int knn, double alpha, int nIter) {
		this.simMatrix = simMatrix;
		this.knn = knn;
		this.alpha = alpha;
		this.nIter = nIter;
	}
	
	private <E> void trimNeighbors(List<Edge<E>> nb, int knn) {
    	Collections.sort(nb, new Comparator<Edge<E>>() {
			@Override
			public int compare(Edge<E> e1, Edge<E> e2) {
				return - Double.compare(e1.weight, e2.weight);
			}});
    	
    	if (nb.size() > knn)
    		nb.subList(knn, nb.size()).clear();
    }
	
	private class DetAttachment {
		public double[] scoreDist;
		public double[] tmpScoreDist;
		public double[] seedDist;
		
		public DetAttachment() {
			scoreDist = new double[SimMatrix.MAX_CAT_ID];
			tmpScoreDist = new double[SimMatrix.MAX_CAT_ID];
			seedDist = new double[SimMatrix.MAX_CAT_ID];
			
			Arrays.fill(scoreDist, 0);
			Arrays.fill(tmpScoreDist, 0);
			Arrays.fill(seedDist, 0);
		}
		
		public void predict(CocoDetection det) throws Exception {
	    	double maxScore = -1;
			int maxCatId = -1;
			for (int catId: simMatrix.getCategoryIds()) 
				if (scoreDist[catId] > maxScore) {
					maxScore = scoreDist[catId];
					maxCatId = catId;
				}
				
			if (maxCatId == -1)
				throw new Exception("Incorrect prediction!");		
			
			det.categoryId = maxCatId;
			det.score = maxScore;				
		}
	}
	
	private DetAttachment getAttachment(Node<CocoDetection> n) {
		return (DetAttachment)n.attachment;
	}
	
	public void adjust(List<CocoDetection> dets) throws Exception {
		
		// graph construction
    	Graph<CocoDetection> g = new Graph<CocoDetection>();
    	for (CocoDetection d : dets) {
    		Node<CocoDetection> n = new Node<CocoDetection>(d);
    		n.attachment = new DetAttachment();
    		g.addNode(n);
    	}
    	
    	for (Node<CocoDetection> n : g.getNodes()) {
    		CocoDetection nd = n.getKey();
    		for (Node<CocoDetection> m : g.getNodes()) {
    			if (n != m) { 
    				CocoDetection md = m.getKey();
    				double w = 1.0 / (nd.computeDistance(md) + 1);
        			n.nb.add(new Edge<CocoDetection>(m, w));
    			}
         	}	
    		trimNeighbors(n.nb, knn);
    	}
    	
    	// make graph fully KNN (a neighbor is added if its the KNN in either direction)
    	for (Node<CocoDetection> n : g.getNodes()) {
    		for (Edge<CocoDetection> e : n.nb) {
    			Node<CocoDetection> m = e.otherEnd;
    			if (!g.containsNb(m.nb, n))
    				m.nb.add(new Edge<CocoDetection>(n, e.weight));
    		}
    	}
    	
    	
    	// init seeds and score
		for (Node<CocoDetection> n : g.getNodes()) {
			int catId = n.getKey().categoryId;
			double score = n.getKey().score;
			getAttachment(n).scoreDist[catId] = score; 
			getAttachment(n).seedDist[catId] = score;
		}
		
		// propagation
		for (int iter = 0; iter < nIter; iter++) {
	    	for (int cat : simMatrix.getCategoryIds()) { 
	    		for (Node<CocoDetection> n : g.getNodes()) {
	    			double sum = 0;
		    		double z = 0;
		    		for (int cat2 : simMatrix.getMSC(cat)) {
		    			double w = simMatrix.getSimilarity(cat, cat2);
		    			for (Edge<CocoDetection> e : n.nb) {
		    				sum += getAttachment(e.otherEnd).scoreDist[cat2] * w;
		    				z += w;
		    			}
			    	}
		   		
		    		if (z > 0) 
		    			getAttachment(n).tmpScoreDist[cat] = (1 - alpha) * sum / z + alpha * getAttachment(n).seedDist[cat];
		    		else
		    			getAttachment(n).tmpScoreDist[cat] = alpha * getAttachment(n).seedDist[cat];
		    	}
	    	}
	    	// update score 
	    	for (Node<CocoDetection> n : g.getNodes())
	    		for (int catId : simMatrix.getCategoryIds())
	    			getAttachment(n).scoreDist[catId] = getAttachment(n).tmpScoreDist[catId];
	    }
    	
		
		
		// revise label and score
		for (Node<CocoDetection> n : g.getNodes()) 	
			getAttachment(n).predict(n.getKey());
		
		

	}
	
	


	
	private static void sort(List<CocoDetection> l) {
		Collections.sort(l, new Comparator<CocoDetection>() {
			
			@Override
			public int compare(CocoDetection d1, CocoDetection d2) {
				return - Double.compare(d1.score, d2.score);
			}} 
    	);
	}
	
	
	public static void filter(List<CocoDetection> dets, double conf, int cand) {
		// remove very low confidence detections
		sort(dets);
		int index = 0;
		while (index < dets.size() && dets.get(index).score >= conf)
			index++;
		if (index < dets.size())
			dets.subList(index, dets.size()).clear();
			
		// only keep a certain number of candidates
		if (dets.size() > cand)
			dets.subList(cand, dets.size()).clear();
		
	}
	
	
	public static void extractTop(List<CocoDetection> dets, int top) {
		if (dets.size() > top) {
			sort(dets);
			int size = Math.min(dets.size(), top);
			dets.subList(size, dets.size()).clear();	
		}
    }
}
