package main;

import java.util.Random;

import utils.Args;
import utils.Comm;
import coco.CocoGroundtruths;
import coco.Groundtruths;
import coco.VocGroundtruths;

public class BuildMatrix {

	public static void main(String[] args) throws Exception {
		String mode = Args.extractString(args, "mode", "cnet");
		String mfile =  Args.extractString(args, "mfile", "matrix_" + mode);
		String dir = Args.extractString(args, "dir", "c:/fangyuan/io/input");
		
		SimMatrix simMatrix = null;
		if (mode.startsWith("freq")) {
			//co occurrence
			System.out.println("Building co-occurrence matrix...");
			
			int k;
			if (mode.equals("freq"))
				k = Integer.MAX_VALUE;
			else
				k = Integer.parseInt(mode.substring(4));
			Groundtruths gt1 = new CocoGroundtruths();
		    gt1.read(dir + "/instances_train2014.json");
		    Groundtruths gt2 = new VocGroundtruths();
	        gt2.read(dir + "/voc_annotations_train");
	        simMatrix = new SimMatrix(dir + "/category_ids_coco.csv", gt1, gt2, new Random(1788490191L), k / 2);
	        simMatrix.save(mfile);
		}
		else if (mode.equals("cnet")) {
			// concept net
			System.out.println("Building conceptnet matrix...");
			simMatrix = new SimMatrix(dir + "/rw_prob", dir + "/category_ids_coco.csv");
			simMatrix.save(mfile);
		}
		else if (mode.equals("rand")) {
			// random
			System.out.println("Building random matrix...");
			simMatrix = new SimMatrix(dir + "/category_ids_coco.csv", new Random(3200198L));
			simMatrix.save(mfile);
		}
		else 
			Comm.quit("Unknow type.");
		
		simMatrix.save(dir + "/" + mfile);
	}

}
