package main;

import coco.CocoResults;
import coco.ImageResult;
import coco.Results;
import coco.VocResults;
import utils.Args;
import utils.Parallel;
import utils.Parallel.Operation;
import utils.Progress;


public class Filter {
	
	public static void main(String[] args) throws Exception {
		final double conf = Args.extractDouble(args, "conf", 1E-5);
        final int cand = Args.extractInt(args, "cand", 500);
        String dataset = Args.extractString(args, "dataset", "coco");
        String dir = Args.extractString(args, "dir", "C:\\fangyuan\\frcnn\\");
        String file = Args.extractString(args, "file", "voc_test");
        
        int cores = Args.extractInt(args, "core", Runtime.getRuntime().availableProcessors() - 1);
		
		// read in original detections
        Results results = null;
        if (dataset.equals("coco")) 
	        results = new CocoResults();
        else if (dataset.equals("voc"))
        	results = new VocResults();
        else {
        	System.err.println("Unknown dataset. Quit now.");
        	System.exit(0);
        }
        
        
        results.read(dir + file);
        
        final Progress prog = new Progress("Filtering image results", results.imageMap.size());
        Parallel.forEach(results.imageMap.values(), cores, new Operation<ImageResult>() {
			@Override
			public void perform(ImageResult imageResult) throws Exception {
				ResultProcessor.filter(imageResult.detections, conf, cand);
				prog.tick();
			}} );
        prog.done();   
        
        results.write(dir + file + "_filtered");  
    }
	
	
}
