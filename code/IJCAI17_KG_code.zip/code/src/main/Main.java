package main;

import coco.CocoResults;
import coco.ImageResult;
import coco.Results;
import coco.VocResults;
import utils.Args;
import utils.Parallel;
import utils.Parallel.Operation;
import utils.Progress;


public class Main {
	
	public static void main(String[] args) throws Exception {
		int knn = Args.extractInt(args, "knn", 5);
		int ncat = Args.extractInt(args, "ncat", 5);
		double alpha = Args.extractDouble(args, "alpha", 0.75);
        int iter = Args.extractInt(args, "iter", 10);
        final int top = Args.extractInt(args, "top", 100);
        String mode = Args.extractString(args, "mode", "cnet");
		String din = Args.extractString(args, "din", "c:/fangyuan/io/input/detections_minival2014_results_1000.json_filtered");
		String dout = Args.extractString(args, "dout", "c:/fangyuan/io/output/detections_minival2014_results_1000.json_filtered");
		String dataset = Args.extractString(args, "dataset", "coco");
		String fcat = Args.extractString(args, "fcat", "c:/fangyuan/io/input/category_ids_" + dataset + ".csv");
		String fmat = Args.extractString(args, "fmat", "c:/fangyuan/io/input/matrix_" + mode);
		
		int cores = Args.extractInt(args, "core", Runtime.getRuntime().availableProcessors() - 1);
				
		SimMatrix simMatrix = new SimMatrix(fcat);
		simMatrix.load(fmat);
		simMatrix.updateMSC(ncat);
		
		final ResultProcessor proc = new ResultProcessor(simMatrix, knn, alpha, iter);
		
		// read in original detections
        Results results = null;
        if (dataset.equals("coco")) 
	        results = new CocoResults();
        else if (dataset.equals("voc"))
        	results = new VocResults();
        else {
        	System.err.println("Unknown dataset. Quit now.");
        	System.exit(0);
        }
        results.read(din);
        
        // processing detections
        System.out.println("Total " + results.imageMap.size() + " images");
        final Progress prog = new Progress("Processing image results", results.imageMap.size());
        Parallel.forEach(results.imageMap.values(), cores, new Operation<ImageResult>() {
			@Override
			public void perform(ImageResult imageResult) throws Exception {
				proc.adjust(imageResult.detections);
				if (top != -1)
					ResultProcessor.extractTop(imageResult.detections, top);
				prog.tick();
			}} );
        prog.done();   
        
        // prepare output
        results.write(dout + "_mode=" + mode + "_knn=" + knn + "_ncat=" + ncat + "_alpha=" + alpha + "_iter=" + iter + "_top=" + top);  
    }
	
	
}
