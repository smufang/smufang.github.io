package cnet;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import gnu.trove.map.hash.THashMap;
import graph.Edge;
import graph.Graph;
import graph.Node;
import utils.TextReader;

public class CNet extends Graph<String> {
	
	private class ConceptAttachment {
		public double score;
		public double tmpScore;
		public double seed;
		public double deg;
		
		public ConceptAttachment() {
			score = 0;
			tmpScore = 0;
			seed = 0;
			deg = 0;
		}
	}
	
	private ConceptAttachment getAttachment(Node<String> n) {
		return (ConceptAttachment)n.attachment;
	}
	
	
	public void load(String file) throws Exception {
		// read nodes
		TextReader in = new TextReader(file);
		String line;
		Pattern nPattern = Pattern.compile("<node id=\"(.*)\" label=\"(.*)\">");		
		
		while ( (line = in.readln()) != null ) {
			Matcher m = nPattern.matcher(line);
			if (m.find()) {
				String id = m.group(1);
				String l = m.group(2);
				Node<String> n = new Node<String>(id);
				n.attachment = new ConceptAttachment();
				n.setLabel(l);
				this.addNode(n);
			}
		}
		in.close();
		
		// read edges
		in = new TextReader(file);
		Pattern ePattern = Pattern.compile("<edge id=\".*\" source=\"(.*)\" target=\"(.*)\" weight=\"(.*)\">");
		while ( (line = in.readln()) != null ) {
			Matcher m = ePattern.matcher(line);
			if (m.find()) {
				Node<String> source = this.getNode(m.group(1));
				Node<String> target = this.getNode(m.group(2));
				double w = Double.parseDouble(m.group(3));
				source.nb.add(new Edge<String>(target, w));
			}
		}
		in.close();
		
		
		// compute deg
		for (Node<String> n : this.getNodes()) {
			for (Edge<String> e : n.nb) 
				getAttachment(n).deg += e.weight;
		}
	}
	
	
	public Map<String, Double> computeRW(final double alpha, Set<String> seeds) throws Exception {
		double teleport = 1.0 / seeds.size();
		for (Node<String> n : this.getNodes()) {
			getAttachment(n).score = seeds.contains(n.getKey()) ? teleport : 0;
			getAttachment(n).seed = getAttachment(n).score;
		}
		
		
		for (int iter = 0; iter < 50; iter++) {
			for (Node<String> n : this.getNodes()) 
				getAttachment(n).tmpScore = 0;
			
			for (Node<String> n : this.getNodes()) {
				for (Edge<String> e : n.nb) {
					Node<String> m = e.otherEnd;
					double w = e.weight;
					getAttachment(m).tmpScore += getAttachment(n).score * w / getAttachment(n).deg;
				}
			}
			
			for (Node<String> n : this.getNodes()) 
				getAttachment(n).score = (1-alpha) * getAttachment(n).tmpScore + alpha * getAttachment(n).seed;
		}
		
		Map<String, Double> result = new THashMap<String, Double>();
		for (Node<String> n : this.getNodes()) 
			result.put(n.getKey(), getAttachment(n).score);		
		return result;
	}
	
	
	private Node<String> getNext(Node<String> cur, Random rnd) {
		if (cur.nb.isEmpty())
			return null;
		else
			return cur.nb.get(rnd.nextInt(cur.nb.size())).otherEnd;
	}
	
	public List<Node<String>> samplePath(double alpha, List<Node<String>> starts, Random rnd) {
		List<Node<String>> l = new ArrayList<Node<String>>();
		
		Node<String> start = starts.get(rnd.nextInt(starts.size()));
		l.add(start);
		Node<String> cur = start;
		while (rnd.nextDouble() >= alpha) {
			Node<String> next = getNext(cur, rnd);
			if (next == null)
				return null;
			l.add(next);
			cur = next;
		}
		
		return l;		
	}

	public List<Node<String>> samplePath(int len, List<Node<String>> starts, Random rnd) {
		List<Node<String>> l = new ArrayList<Node<String>>();
		
		Node<String> start = starts.get(rnd.nextInt(starts.size()));
		l.add(start);
		Node<String> cur = start;
		while (l.size() < len) {
			Node<String> next = getNext(cur, rnd);
			if (next == null)
				return null;
			l.add(next);
			cur = next;
		}
		
		return l;		
	}
	
}
