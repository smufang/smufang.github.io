package graph;


public class Edge<T> {
	
	
	public Node<T> otherEnd;
	public double weight;
	
	public Edge(Node<T> otherEnd, double weight) {
		this.otherEnd = otherEnd;
		this.weight = weight; 
	}

}
