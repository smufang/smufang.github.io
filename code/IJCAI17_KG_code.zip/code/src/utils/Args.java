package utils;

public class Args {

	public static String extractString(String[] args, String argName, String defValue) {
		String prefix = argName + "=";
		for (String arg : args) {
			if (arg.startsWith(prefix))
				return arg.substring(prefix.length()).trim();
		}
		return defValue;
	}
	
	public static int extractInt(String[] args, String argName, int defValue) {
		String s = extractString(args, argName, null);
		if (s == null)
			return defValue;
		else
			return Integer.parseInt(s);
	}
	
	public static double extractDouble(String[] args, String argName, double defValue) {
		String s = extractString(args, argName, null);
		if (s == null)
			return defValue;
		else
			return Double.parseDouble(s);
	}
	
	public static boolean extractBool(String[] args, String argName, boolean defValue) {
		String s = extractString(args, argName, null);
		if (s == null)
			return defValue;
		else
			return Boolean.parseBoolean(s);
	}
	
}
