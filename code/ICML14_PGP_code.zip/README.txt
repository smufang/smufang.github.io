The enclosed datasets are used in our following paper:

Yuan Fang, Kevin C.-C. Chang and Hady W. Lauw. Graph-based Semi-supervised Learning: Realizing Pointwise Smoothness Probabilistically. In ICML 2014 (2), pp. 406--414.

Each file contains one dataset. Each row is an instance. The first column is the class label of the instance in that row, and the subsequent columns are features of the instance. The columns are tab delimited.  