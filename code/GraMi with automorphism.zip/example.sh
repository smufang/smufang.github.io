./grami -f myGraph.lg -s 1 -t 0 -p 0 -n 5 -o subgraphsWithAutomorphism -o2 originalSubgraphsOutput
