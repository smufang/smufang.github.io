We release some modifications of GraMi code such that the output would include automophism information.

Please download the original GraMi code from 
https://github.com/ehab-abdelhamid/GraMi

In our release we only included the modified source code. Copy and paste them to replace the original code.

We also updated the grami command line execution file, with two new options:
-o			output subgraphs with automorphism
-o2			output subgraphs (i.e., original output file)